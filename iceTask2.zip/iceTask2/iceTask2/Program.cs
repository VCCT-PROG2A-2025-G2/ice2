﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace iceTask2
{
    class Program
    {
        static void Main()
        {
            string[] soundFiles = {
            "sound1.wav",
            "sound2.wav",
            "sound3.wav"
        };

            bool[] played = new bool[soundFiles.Length];

            while (true)
            {
                Console.Clear();
                Console.WriteLine("Select a sound to play:");
                for (int i = 0; i < soundFiles.Length; i++)
                {
                    if (played[i])
                    {
                        Console.ForegroundColor = ConsoleColor.Green;
                    }
                    Console.WriteLine($"{i + 1}. {soundFiles[i]}");
                    Console.ResetColor();
                }

                Console.Write("Enter the number of the sound to play (or 'q' to quit): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "q")
                    break;

                if (int.TryParse(input, out int choice) && choice >= 1 && choice <= soundFiles.Length)
                {
                    PlaySound(soundFiles[choice - 1]);
                    played[choice - 1] = true;
                }
                else
                {
                    Console.WriteLine("Invalid selection. Press any key to try again.");
                    Console.ReadKey();
                }
            }
        }

        static void PlaySound(string filePath)
        {
            try
            {
                using (SoundPlayer player = new SoundPlayer(filePath))
                {
                    player.PlaySync();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error playing sound: " + ex.Message);
            }
        }
    }
}
